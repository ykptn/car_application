package com.example.myrvexample.model

data class Car(val name: String, val specs: String, val performance: String)