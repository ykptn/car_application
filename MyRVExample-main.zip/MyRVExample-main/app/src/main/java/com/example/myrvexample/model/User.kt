package com.example.myrvexample.model

data class User(val name: String, val profileDesc: String, val address: String)